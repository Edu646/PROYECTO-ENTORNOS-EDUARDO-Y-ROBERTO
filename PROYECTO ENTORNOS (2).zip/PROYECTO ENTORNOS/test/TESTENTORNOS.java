/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5Suite.java to edit this template
 */

import proyecto.entornos.PhoneNumberValidator;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;

/**
 *
 * @author Asus
 */

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

 class PhoneNumberValidatorTest {

    @Test
    public void testValidPhoneNumber() {
        String phoneNumber = "123-456-7890";
        assertTrue(PhoneNumberValidator.isValidPhoneNumber(phoneNumber));
    }

    @Test
    public void testInvalidPhoneNumber() {
        String phoneNumber = "1234567890";
        assertEquals(PhoneNumberValidator.isValidPhoneNumber(phoneNumber));
    }

        private void assertEquals(boolean validPhoneNumber) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}


