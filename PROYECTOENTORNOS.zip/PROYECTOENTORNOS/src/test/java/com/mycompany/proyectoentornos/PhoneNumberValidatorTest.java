/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.proyectoentornos;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Usuario
 */
    

    public class PhoneNumberValidatorTest {
    private PrintStream originalOut;
    private ByteArrayOutputStream outContent;

    @BeforeEach
    public void setUp() {
        originalOut = System.out;
        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
    }

    @AfterEach
    public void tearDown() {
        System.setOut(originalOut);
    }

    @Test
    public void testIsValidPhoneNumber() {
        System.out.println("isValidPhoneNumber");
        String phoneNumber = "1234567890";
        boolean expResult = true;
        boolean result = PhoneNumberValidator.isValidPhoneNumber(phoneNumber);
        assertEquals(expResult, result);
    }

    @Test
  public void testMain() {
    System.out.println("main");
    String[] args = null;

    // Redirigir la salida estándar a un ByteArrayOutputStream
    ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    System.setOut(new PrintStream(outContent));

    PhoneNumberValidator.main(args);

    // Verificar si se imprime el mensaje correcto
    String expectedOutput = "El numero de telefono es valido.";
    assertTrue(outContent.toString().contains(expectedOutput));
}
    }
    

