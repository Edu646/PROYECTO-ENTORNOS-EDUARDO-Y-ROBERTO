/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.calculadora;

import java.util.Scanner;

/**
 *
 * @author rober
 */
public class Calculadora {

public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcion = 0;
        
        do {
            // mostrar menú
            System.out.println("Seleccione una opción:");
            System.out.println("1. Suma");
            System.out.println("2. Resta");
            System.out.println("3. Multiplicación");
            System.out.println("4. División");
            System.out.println("5. Número primo");
            System.out.println("6. Salir");
            opcion = sc.nextInt();
            
            switch (opcion) {
                case 1:
                    System.out.println("El resultado de la suma es: " + sumar());
                    break;
                case 2:
                    System.out.println("El resultado de la resta es: " + restar());
                    break;
                case 3:
                    System.out.println("El resultado de la multiplicación es: " + multiplicar());
                    break;
                case 4:
                    System.out.println("El resultado de la división es: " + dividir());
                    break;
                case 5:
                    if (esPrimo()) {
                        System.out.println("El resultado de esta operación es: Primo");
                    } else {
                        System.out.println("El resultado de esta operación no es primo");
                    }
                    break;
                case 6:
                    System.out.println("Saliendo de la calculadora");
                    break;
                default:
                    System.out.println("Opción inválida");
                    break;
            }
            
        } while (opcion != 6);
        
        sc.close();
    }
    
    public static int sumar() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el primer número: ");
        int num1 = sc.nextInt();
        System.out.println("Ingrese el segundo número: ");
        int num2 = sc.nextInt();
        return num1 + num2;
    }
    
    public static int restar() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el primer número: ");
        int num1 = sc.nextInt();
        System.out.println("Ingrese el segundo número: ");
        int num2 = sc.nextInt();
        return num1 - num2;
    }
    
    public static int multiplicar() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el primer número: ");
        int num1 = sc.nextInt();
        System.out.println("Ingrese el segundo número: ");
        int num2 = sc.nextInt();
        return num1 * num2;
    }
    
    public static int dividir() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el dividendo: ");
        int dividendo = sc.nextInt();
        System.out.println("Ingrese el divisor: ");
        int divisor = sc.nextInt();
        return dividendo / divisor;
    }
    
    public static boolean esPrimo() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese un número: ");
        int num = sc.nextInt();
        if (num < 2) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static int dividir(int dividendo, int divisor) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
